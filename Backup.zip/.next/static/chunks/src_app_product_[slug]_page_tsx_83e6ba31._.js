(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_product_[slug]_page_tsx_83e6ba31._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_product_[slug]_page_tsx_83e6ba31._.js",
  "chunks": [
    "static/chunks/src_63a41e1c._.js",
    "static/chunks/node_modules_5dc15bec._.js",
    "static/chunks/node_modules_slick-carousel_slick_eab2732a._.css"
  ],
  "source": "dynamic"
});

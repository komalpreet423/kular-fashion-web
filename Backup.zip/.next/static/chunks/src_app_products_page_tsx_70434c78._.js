(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_products_page_tsx_70434c78._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_products_page_tsx_70434c78._.js",
  "chunks": [
    "static/chunks/src_77600823._.js",
    "static/chunks/node_modules_react-icons_im_index_mjs_b2963581._.js",
    "static/chunks/node_modules_react-icons_md_index_mjs_78df2b41._.js",
    "static/chunks/node_modules_react-icons_sl_index_mjs_f0cdce93._.js",
    "static/chunks/node_modules_ac215706._.js"
  ],
  "source": "dynamic"
});

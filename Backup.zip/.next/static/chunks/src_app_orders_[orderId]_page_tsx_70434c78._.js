(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_orders_[orderId]_page_tsx_70434c78._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_orders_[orderId]_page_tsx_70434c78._.js",
  "chunks": [
    "static/chunks/src_app_orders_[orderId]_page_tsx_57387c82._.js"
  ],
  "source": "dynamic"
});

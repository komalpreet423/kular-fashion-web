(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_wishlist_page_tsx_70434c78._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_wishlist_page_tsx_70434c78._.js",
  "chunks": [
    "static/chunks/node_modules_react-icons_im_index_mjs_b2963581._.js",
    "static/chunks/src_869e1562._.js"
  ],
  "source": "dynamic"
});

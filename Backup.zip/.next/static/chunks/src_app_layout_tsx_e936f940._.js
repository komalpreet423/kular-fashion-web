(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_e936f940._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_e936f940._.js",
  "chunks": [
    "static/chunks/[root of the server]__7a7a1f5e._.css",
    "static/chunks/src_4b0f124a._.js",
    "static/chunks/node_modules_next_eeefdadc._.js",
    "static/chunks/node_modules_react-icons_ci_index_mjs_e4544c82._.js",
    "static/chunks/node_modules_react-icons_bs_index_mjs_0b2b1793._.js",
    "static/chunks/node_modules_react-icons_ai_index_mjs_b8cfc3ce._.js",
    "static/chunks/node_modules_react-icons_gr_index_mjs_42e3d99f._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
    "static/chunks/node_modules_react-icons_fi_index_mjs_9cbf4bb1._.js",
    "static/chunks/node_modules_react-icons_io5_index_mjs_39106f7b._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
    "static/chunks/node_modules_framer-motion_dist_es_d360d841._.js",
    "static/chunks/node_modules_6e85ab74._.js"
  ],
  "source": "dynamic"
});

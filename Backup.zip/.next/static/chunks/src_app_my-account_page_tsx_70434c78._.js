(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_my-account_page_tsx_70434c78._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_my-account_page_tsx_70434c78._.js",
  "chunks": [
    "static/chunks/src_585c3766._.js",
    "static/chunks/node_modules_03f915a3._.js"
  ],
  "source": "dynamic"
});

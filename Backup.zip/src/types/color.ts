export interface ColorDetail {
    id: number;
    name: string;
    slug: string;
    short_name: string;
    code: string;
    ui_color_code: string;
    status: string;
}
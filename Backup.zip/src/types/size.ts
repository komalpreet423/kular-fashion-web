export interface SizeDetail {
    id: number;
    size_scale_id: number;
    name: string;
    new_code: string;
    old_code: string | null;
    length: string | null;
    status: string;
}
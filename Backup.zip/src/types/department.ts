export interface Department {
    id: number;
    name: string;
    slug: string;
    image: string;
    description: string;
    status: string;
}
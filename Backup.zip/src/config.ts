export const apiBaseUrl = `http://127.0.0.1:8000/api/`;
export const apiBaseRoot = `http://127.0.0.1:8000/`;